import { supabase } from "./supabaseClient.js";

/* CREATE REQUEST */
export async function submitHelpRequest(data, userId) {
  const { data: inserted, error } = await supabase
    .from("help_requests")
    .insert([
      {
        ...data,
        created_by: userId
      }
    ])
    .select()
    .single();

  if (error) throw error;
  return inserted;
}

/* READ MY REQUESTS */
export async function getMyRequests(userId) {
  const { data, error } = await supabase
    .from("help_requests")
    .select("*")
    .eq("created_by", userId)
    .order("created_at", { ascending: false });

  if (error) throw error;
  return data;
}

/* READ URGENT */
export async function getUrgentRequests() {
  const { data, error } = await supabase
    .from("help_requests")
    .select("*")
    .in("urgency", ["high", "critical"])
    .eq("status", "open");

  if (error) throw error;
  return data;
}

/* UPDATE */
export async function resolveRequest(requestId, userId) {
  const { data, error } = await supabase
    .from("help_requests")
    .update({ status: "resolved" })
    .eq("id", requestId)
    .eq("created_by", userId)
    .select()
    .single();

  if (error) throw error;
  return data;
}

/* RESOURCES */
export async function offerResource(data, userId) {
  const { data: inserted, error } = await supabase
    .from("resources")
    .insert([
      {
        title: data.title,
        type: data.type,
        quantity: data.quantity,
        pickup_location: data.location,
        offered_by: userId
      }
    ])
    .select()
    .single();

  if (error) throw error;
  return inserted;
}

export async function getResources() {
  const { data, error } = await supabase
    .from("resources")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) throw error;
  return data;
}

/* DASHBOARD */
export async function loadDashboard(userId) {
  return {
    myRequests: await getMyRequests(userId),
    urgentRequests: await getUrgentRequests(),
    resources: await getResources()
  };
}
